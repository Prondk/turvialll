client.on("message", async message => {
    if(message.author.bot) return;
    if(message.content.indexOf(prefix) !== 0) return;
    const args = message.content.slice(ayarlar.prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();
      if (command === "espri") {
      
      var request = require('request');
      request('https://api.eggsybot.xyz/espri', function (error, response, body) {
      if (error) return console.log('Hata:', error); // Hata olursa, konsola göndersin,
      else if (!error) { // Eğer hata yoksa;
          var info = JSON.parse(body); // info değişkeninin içerisine JSON'ı ayrıştırsın,
          message.channel.send('**Espri**: ' + info.soz); // ve konsola çıktıyı versin.
      }
  });    
  }
  }); 